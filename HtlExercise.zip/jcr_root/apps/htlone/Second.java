import javax.script.Bindings;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.scripting.sightly.pojo.Use;


public class Second implements Use {

   private Iterable<Resource> res;

    @Override
    public void init(Bindings bindings) {

        ResourceResolver resourceResolver = (ResourceResolver)bindings.get("resolver");
        res = resourceResolver.getResource("/content/my-options").getChildren();
    }

    public Iterable<Resource> getRes() {
        return this.res;
    }

}